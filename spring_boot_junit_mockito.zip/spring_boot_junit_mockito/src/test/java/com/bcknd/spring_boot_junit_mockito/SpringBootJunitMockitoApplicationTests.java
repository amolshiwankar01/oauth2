package com.bcknd.spring_boot_junit_mockito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringBootJunitMockitoApplicationTests {

    @Test
    void contextLoads() {
    }

}
