package com.bcknd.spring_boot_junit_mockito.test;

import com.bcknd.spring_boot_junit_mockito.SpringBootJunitMockitoApplicationTests;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK, classes = {SpringBootJunitMockitoApplicationTests.class})
public class SpringUnitTest {

}
