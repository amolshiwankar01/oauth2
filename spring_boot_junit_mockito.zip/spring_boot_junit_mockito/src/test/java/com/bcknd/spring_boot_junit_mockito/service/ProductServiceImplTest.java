package com.bcknd.spring_boot_junit_mockito.service;

import com.bcknd.spring_boot_junit_mockito.model.Product;
import com.bcknd.spring_boot_junit_mockito.repo.ProductRepository;
import com.bcknd.spring_boot_junit_mockito.test.SpringUnitTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

public class ProductServiceImplTest extends SpringUnitTest {

    @InjectMocks
    ProductServiceImpl productServiceImpl;

    @Mock
    Product product;

    @Mock
    ProductRepository productRepository;

    @BeforeEach
    public void init() {
        Mockito.when(product.getId()).thenReturn(1L);
        Mockito.when(product.getProductName()).thenReturn("T-Shirt");
        Mockito.when(product.getProductPrice()).thenReturn(500.00);
        Mockito.when(product.getProductCategory()).thenReturn("Clothing");
    }

    @Test
    public void testCreateProduct() {
        Mockito.when(productRepository.save(Mockito.any())).thenReturn(product);
        //Product createdItem = productServiceImpl.create(product);
        assertEquals("T-Shirt", productServiceImpl.create(product).getProductName());
    }

    @Test
    public void testGetProducts() {
        Mockito.when(productRepository.findAll()).thenReturn(Arrays.asList(product));
        //List<Product> productItems=productServiceImpl.getProducts();
        assertEquals(1, productServiceImpl.getProducts().size());

    }

    @Test
    public void testUpdateProduct() {
        Mockito.when(product.getProductName()).thenReturn("Shirt");
        Mockito.when(productRepository.save(Mockito.any())).thenReturn(product);
        //Product updatedItem=productServiceImpl.update(product, product.getId());
        assertEquals("Shirt", productServiceImpl.update(product, product.getId()).getProductName());

    }

    @Test
    @Timeout(value = 1000)
    public void testDeleteProduct() {
        Mockito.doNothing().when(productRepository).delete(Mockito.any());
        Mockito.when(productRepository.findById(1L)).thenReturn(Optional.of(product));
        ProductServiceImpl service=mock(ProductServiceImpl.class);

        service.delete(1L);
        verify(service).delete(Mockito.anyLong());
    }

    @Test
    public void testGetProductById() {
        Mockito.when(productRepository.findFirstById(1L)).thenReturn(Optional.of(product));
        //Product product = productServiceImpl.getProductById(1L);
        assertEquals(1L, productServiceImpl.getProductById(1L).get().getId());
    }
}
