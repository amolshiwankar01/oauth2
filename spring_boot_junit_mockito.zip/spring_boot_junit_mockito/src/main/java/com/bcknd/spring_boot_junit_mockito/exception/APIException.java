package com.bcknd.spring_boot_junit_mockito.exception;

public class APIException extends RuntimeException{
}
