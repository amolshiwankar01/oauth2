package com.bcknd.spring_boot_junit_mockito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJunitMockitoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootJunitMockitoApplication.class, args);
    }

}
