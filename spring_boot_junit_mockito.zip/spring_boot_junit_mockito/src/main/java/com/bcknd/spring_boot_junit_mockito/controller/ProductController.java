package com.bcknd.spring_boot_junit_mockito.controller;


import com.bcknd.spring_boot_junit_mockito.exception.ProductNotFoundException;
import com.bcknd.spring_boot_junit_mockito.model.Product;
import com.bcknd.spring_boot_junit_mockito.service.ProductService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@AllArgsConstructor
@RestController
@RequestMapping("/product/")
public class ProductController {

    @Autowired
    ProductService productService;


    @GetMapping
    public ResponseEntity<List<Object>> findAllUsers(){
        return new ResponseEntity(productService.getProducts(), HttpStatus.OK);
    }


    @PostMapping
    public ResponseEntity<Object> create(@RequestBody Product product){
        return new ResponseEntity(productService.create(product), HttpStatus.OK);
    }


    @GetMapping("{id}")
    public ResponseEntity<Object> findById(@PathVariable("id") long id){
        return productService.getProductById(id)
                .map(product->new ResponseEntity(product,HttpStatus.OK))
                .orElseThrow(()->new ProductNotFoundException("Product not found"));
    }
}
