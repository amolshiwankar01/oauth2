package com.bcknd.spring_boot_junit_mockito.service;

import com.bcknd.spring_boot_junit_mockito.model.Product;
import com.bcknd.spring_boot_junit_mockito.repo.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImpl implements ProductService{


    @Autowired
    ProductRepository productRepository;

    @Override
    public Product create(Product product) {
        Product createdItem = productRepository.save(product);
        return createdItem;
    }

    @Override
    public List<Product> getProducts() {
        return productRepository.findAll();
    }

    @Override
    public void delete(long id) {
        Optional<Product> product = productRepository.findById(id);
        productRepository.delete(product.get());
    }

    @Override
    public Product update(Product product, Long id) {
        Product updateItem = productRepository.save(product);
        return updateItem;
    }

    @Override
    public Optional<Product> getProductById(Long id) {
        return productRepository.findFirstById(id);
    }

}
