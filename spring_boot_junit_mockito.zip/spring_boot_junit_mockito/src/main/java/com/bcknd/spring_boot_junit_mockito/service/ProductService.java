package com.bcknd.spring_boot_junit_mockito.service;

import com.bcknd.spring_boot_junit_mockito.model.Product;

import java.util.List;
import java.util.Optional;

public interface ProductService {
    public Product create(Product product);
    public List<Product> getProducts();
    public void delete(long id);
    public Product update(Product product,Long id);
    public Optional<Product> getProductById(Long id);
}
