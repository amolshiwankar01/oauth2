package com.techdot.soft.bcknd.exception;

import java.util.List;

public class ServiceException extends Exception {
    public List<String> getValidationErros() {
        return validationErros;
    }
    public void setValidationErros(List<String> validationErros) {
        this.validationErros = validationErros;
    }
    private static final long serialVersionUID = 4230251609470525132L;
    List<String> validationErros;

    public ServiceException(String message) {
        super(message);
    }
    public ServiceException(String message,List<String> validationErros) {
        super(message);
        this.validationErros=validationErros;
    }



}
