package com.techdot.soft.bcknd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticalTechdotsoftApplication {

    public static void main(String[] args) {
        SpringApplication.run(PracticalTechdotsoftApplication.class, args);
    }

}
