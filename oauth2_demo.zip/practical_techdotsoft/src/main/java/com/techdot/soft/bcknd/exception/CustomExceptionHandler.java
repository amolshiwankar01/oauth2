package com.techdot.soft.bcknd.exception;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.TypeMismatchException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@SuppressWarnings({ "unchecked", "rawtypes" })
@ControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
        Map<String, Object> body = new HashMap<String, Object>();
        body.put("timestamp", new Date());
        body.put("status", 500);
        List<String> details = new ArrayList<>();
        details.add(ex.getLocalizedMessage());
        body.put("errors", details);
        return new ResponseEntity(body, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(DataNotFoundException.class)
    public final ResponseEntity<Object> handleNotFoundException(DataNotFoundException ex, WebRequest request) {
        Map<String, Object> body = new HashMap<String, Object>();
        body.put("timestamp", new Date());
        body.put("status", HttpStatus.NO_CONTENT);
        List<String> details = new ArrayList<>();
        details.add(ex.getLocalizedMessage());
        body.put("errors", details);
        return new ResponseEntity(body, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(ValidationException.class)
    public final ResponseEntity<Object> validationException(ValidationException ex, WebRequest request) {
        Map<String, Object> body = new HashMap<String, Object>();
        body.put("timestamp", new Date());
        body.put("status", HttpStatus.NO_CONTENT);
        List<String> details = new ArrayList<>();
        details.add(ex.getLocalizedMessage());
        body.put("errors", details);
        return new ResponseEntity(body, HttpStatus.NO_CONTENT);
    }


    @ExceptionHandler(ServiceException.class)
    public final ResponseEntity<Object> handleDataIntegrityViolationException(ServiceException ex, WebRequest request) {
        Map<String, Object> body = new HashMap<String, Object>();
        body.put("timestamp", new Date());
        body.put("status", 503);
        List<String> details = new ArrayList<>();
//		if (ex.getValidationErros() != null || ex.getValidationErros().size() != 0) {
        if (ex.getValidationErros() != null) {
            for (String string : ex.getValidationErros()) {
                details.add(string);
            }
        } else {
            details.add(ex.getLocalizedMessage());
        }

        body.put("errors", details);
        return new ResponseEntity(body, HttpStatus.CONFLICT);
    }
}
