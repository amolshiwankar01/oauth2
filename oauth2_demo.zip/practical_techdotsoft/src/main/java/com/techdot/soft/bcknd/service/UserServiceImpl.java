package com.techdot.soft.bcknd.service;


import com.techdot.soft.bcknd.exception.DataNotFoundException;
import com.techdot.soft.bcknd.exception.ValidationException;
import com.techdot.soft.bcknd.model.User;
import com.techdot.soft.bcknd.repositories.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service(value = "userService")
@Slf4j
public class UserServiceImpl implements UserDetailsService, UserService {


    @Autowired
    private UserRepository userRepository;

    public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(userId);
        if(user == null){
            throw new UsernameNotFoundException("Invalid username or password.");
        }
        return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), getAuthority());
    }

    private List<SimpleGrantedAuthority> getAuthority() {
        return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
    }

    public List<User> findAll() {
        List<User> list = new ArrayList<>();
        userRepository.findAll().iterator().forEachRemaining(list::add);
        return list;
    }

    @Override
    public User save(User user) throws DataNotFoundException {
        User userDB = userRepository.findByUsername(user.getUsername());
        if(userDB != null){
            throw new DataNotFoundException("username is already exits.!");
        }
        return userRepository.save(user);
    }


    @Override
    public User profileById(Integer id) throws DataNotFoundException  {
        User user = null;
        user = userRepository.findFirstById(id);
        if(user == null){
            log.error("user is not exist");
            throw new DataNotFoundException("user id" + id + " not present.");
        }
        return user;
    }

    @Override
    public User passwordUpdateById(Integer id, String password) throws DataNotFoundException  {
        User user = null;
        if(!StringUtils.isEmpty(id) && !StringUtils.isEmpty(password) ) {
            user = userRepository.findFirstById(id);
            if(user != null){
                user.setPassword(password);
                user = userRepository.save(user);
            } else {
                log.error("user is not exist");
                throw new DataNotFoundException("user id-" + id + " not present.");
            }
        } else {
            log.error("user id or password is not provided");
            throw new DataNotFoundException("username or password is not provided.");
        }
        return user;
    }

    @Override
    public User login(String username, String password) throws DataNotFoundException {
        User user = null;
        if(!StringUtils.isEmpty(username) && !StringUtils.isEmpty(password) ) {
            user = userRepository.findByUsernameAndPassword(username,password);
            if(user == null){
                log.error("username is not exist");
                throw new DataNotFoundException("user " + username + " not present.");
            }
        } else {
            log.error("username or password is not provided");
            throw new DataNotFoundException("username or password is not provided.");
        }
        return user;
    }
}
