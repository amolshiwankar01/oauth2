package com.techdot.soft.bcknd.service;

import com.techdot.soft.bcknd.exception.DataNotFoundException;
import com.techdot.soft.bcknd.exception.ValidationException;
import com.techdot.soft.bcknd.model.User;

import java.util.List;

public interface UserService {
    User save(User user) throws DataNotFoundException;
    List<User> findAll();
    User profileById(Integer id) throws DataNotFoundException;
    User passwordUpdateById(Integer id, String password) throws DataNotFoundException;
    User login(String username, String password) throws DataNotFoundException;
}
