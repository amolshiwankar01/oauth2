package com.techdot.soft.bcknd.controller;

import com.techdot.soft.bcknd.exception.DataNotFoundException;
import com.techdot.soft.bcknd.exception.ValidationException;
import com.techdot.soft.bcknd.model.User;
import com.techdot.soft.bcknd.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;
import java.util.List;

@RestController
@RequestMapping("/users")
@Slf4j
public class UserController {

    @Autowired
    private UserService userService;


    @GetMapping("all")
    public List<User> listUser(){
        return userService.findAll();
    }

    @PostMapping("save")
    public User create(@RequestBody User user) throws DataNotFoundException{
        return userService.save(user);
    }

    @GetMapping("profile/{id}")
    public User profileById(@PathVariable(value = "id") Integer id) throws DataNotFoundException {
        return userService.profileById(id);
    }

    @PutMapping("password")
    public User passwordUpdateById(@PathParam(value = "id") Integer id, @PathParam(value = "password") String password) throws DataNotFoundException{
        return userService.passwordUpdateById(id,password);
    }

    @PostMapping("login")
    public User login(@PathParam(value = "username") String username, @PathParam(value = "password") String password) throws DataNotFoundException {
        return userService.login(username,password);
    }

}
