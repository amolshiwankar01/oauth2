package com.techdot.soft.bcknd;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticalTechdotsoftApplicationTests {


    void contextLoads() {
    }

}
